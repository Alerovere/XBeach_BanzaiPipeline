Download XBeach and unzip in this folder: https://oss.deltares.nl/web/xbeach/source-code-and-exe 
This model has been tested with "XBeach rev. 5834 x64 (with netcdf support)".
To change wave conditions, edit the "jonswap" file. To change tides, edit the "tide" file.